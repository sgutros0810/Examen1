package es.iesf1.lluviadeobjetos;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Clase que implementa el código la aplicación.
 *
 * @author Pepe Robles
 */
public class LLuviaDeObjetos {
    /**
     * Variable que controla la terminación del programa cuando se pulsa ESC
     */
    private boolean exit;
    /**
     * Variables que representan el terminal y la pantalla, aunque solo interactuaremos con
     * la screen, terminal se utiliza en el constructor de screen
     */
    private Terminal terminal;
    private Screen screen;
    /**
     * Ancho y alto de la pantalla
     */
    private int width;
    private int height;

    /**
     * Variables que controlan los frames por segundo
     */
    private LocalDateTime currentFrameTime;
    private LocalDateTime lastFrameTime;
    /**
     * Frames por segundo del programa
     */
    final private int FPS = 5;
    /**
     * Tiempo que debe tardar un frame por segundo en dibujarse para alcanzar los FPS de la aplicación
     */
    final private long FPS_MILLIS = (long) (1.0 / FPS * 1000);

    /**
     * Constructor por defecto de la aplicación. Inicializa e instancia las variables de estado.
     * @throws IOException disparada por los métodos de la librería lanterna.
     */
    public LLuviaDeObjetos() throws IOException {
        // Creamos un emulador de terminal a través de la factoría de terminales por defecto.
        DefaultTerminalFactory defaultTerminalFactory = new DefaultTerminalFactory();
        terminal = defaultTerminalFactory.createTerminalEmulator();

        // Inicializamos una pantalla (screen) que utilizará al terminal para emitir su salida.
        screen = new TerminalScreen(terminal);
        // Ejecutamos los métodos especificados en la documentación para utilizar el screen.
        screen.startScreen();
        screen.setCursorPosition(null);

        // Obtenemos el tamaño de la pantalla/terminal
        getScreenSize();

        // Capturamos el instante de tiempo en el que se instancia la aplicación para dar valores iniciales
        // a las variables usadas para el cálculo del frame rate.
        currentFrameTime = LocalDateTime.now();
        lastFrameTime = currentFrameTime;
    }

    /**
     * Bucle de la aplicación donde se orquestan las distintas funcionalidades de la app.
     * @throws IOException disparada por los métodos de la librería lanterna.
     * @throws InterruptedException disparada por los métodos de la librería lanterna.
     */
    public void run() throws IOException, InterruptedException {
        // Variables para la gestión de un frame rate fijo usando un retardo adaptativo
        long delta;
        long sleepMillis;

        // exit será verdad cuando se pulse la tecla escape, gestionado en el método processUserInput().
        while (!exit) {
            // Procesamos la interacción con el usuario.
            processUserInput();
            // Actualizamos las dimensiones de la pantalla por si han cambiado desde la última iteración.
            getScreenSize();
            // Actualizamos la escena
            updateScene();
            // Limpiamos la pantalla
            clearScreen();
            // Dibujamos la escena
            drawScene();

            // Introducimos un retardo para ralentizar la velocidad de la aplicación.
            // Thread.sleep le indica al scheduler del sistema operativo que nos pase a la cola
            // de dormidos durante un tiempo en milisegundos determinado.

            // Calculamos los milisegundos que se ha tardado en dar una vuelta al bucle y le restamos
            // el tiempo tardado al tiempo que tardaría un frame en milisegundos, de esta forma
            // mantendremos constante el frame rate.
            currentFrameTime = LocalDateTime.now();
            delta = ChronoUnit.MILLIS.between(lastFrameTime, currentFrameTime);

            if (delta < FPS_MILLIS) {
                sleepMillis = FPS_MILLIS - delta;
                Thread.sleep(sleepMillis);
            }

            // Una vez finalizado el frame, guardamos el instante de tiempo para el siguiente frame
            lastFrameTime = currentFrameTime;
        }

        // Cerramos la pantalla que consecuentemente cerrará el terminal
        screen.close();
    }

    /**
     * Guarda en <strong>width</strong> y <strong>height</strong> el ancho y alto de la pantalla.
     * @throws IOException disparada por los métodos de la librería lanterna.
     */
    private void getScreenSize() throws IOException {
        // Esta función redimensiona los buffers internos de las dos pantallas usadas para
        // implementar el double buffering. Si no se llama la pantalla no se enterará del cambio
        // de dimensiones del terminal.
        screen.doResizeIfNecessary();
        // Solicitamos el tamaño del terminal
        TerminalSize ts = screen.getTerminalSize();
        // Guardamos en width y height las filas y columnas que determinan el tamaño del aera de trabajo.
        width = ts.getColumns();
        height = ts.getRows();
    }

    /**
     * Procesa la entrada del usuario por teclado.
     * @see <a href="https://github.com/mabe02/lanterna/blob/master/docs/using-terminal.md#read-keyboard-input"</a>
     * @throws IOException puede ser lanzada por pollInput en caso de error de entrada salida.
     */
    private void processUserInput() throws IOException {
        // LLamamos al método no bloqueante pollInput, si el valor devuelto es null no hay ninguna tecla en
        // el buffer de teclado, en caso contrario KeyStroke almacena la tecla pulsada.
        KeyStroke ks = screen.pollInput();

        if (ks != null) {
            // Averiguamos el tipo de tecla pulsada y la procesamos.
            KeyType kt = ks.getKeyType();
            switch (kt) {
                // Tecla de terminación/salida del programa.
                case Escape:
                case EOF:
                    exit = true;
                    break;
                case Character:
                    // Si es un caracter lo procesamos
                    Character c = ks.getCharacter();
                    break;
            }
        }
    }

    /**
     * Limpia la pantalla
     * @throws IOException disparada por los métodos de la librería lanterna.
     */
    private void clearScreen() throws IOException {
        screen.clear();
    }

    /**
     * Actualiza la escena.
     *
     * En este método se instará a los objetos a actualizarse para tener un nuevo estado de los objetos
     * que componen la escena de nuestro programa para posteriormente ser dibujados
     */
    private void updateScene() {
        // Actualiza la escena
    }

    /**
     * Dibuja la escena.
     *
     * drawScene delega en los objetos que componen la escena la funcionalidad de dibujarse
     * @throws IOException
     */
    private void drawScene() throws IOException {
        // Dibuja la escena

        // Finalmente aplica el double buffering
        screen.refresh();
    }
}

