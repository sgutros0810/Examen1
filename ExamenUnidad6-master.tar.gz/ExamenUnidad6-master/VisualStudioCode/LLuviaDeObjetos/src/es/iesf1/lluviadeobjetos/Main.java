package es.iesf1.lluviadeobjetos;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException {
        new LLuviaDeObjetos().run();
    }
}
